<?php
$player=array (
  'ads' => 
  array (
    'status' => '1',
    'vip' => '1',
    'group' => '1',
  ),
  'pre' => 
  array (
    'status' => '1',
    'url' => '',
  ),
  'logo' => 
  array (
    'status' => '1',
    'url' => '',
  ),
  'copyright' => 
  array (
    'status' => '1',
    'content' => '追剧猫',
    'url' => '',
  ),
  'dp' => 
  array (
    'auto' => '1',
    'last' => '1',
    'next' => '1',
    'h5' => NULL,
  ),
);
$pre=array (
  'ads' => 
  array (
    'status' => '1',
    'time' => '5',
    'button' => '1',
    'auth' => '0',
    'group' => '3',
  ),
  'pic' => 
  array (
    'status' => '1',
    'img' => '',
    'link' => '',
    'width' => '',
    'height' => '',
  ),
  'vod' => 
  array (
    'status' => '0',
    'url' => '',
    'link' => '',
  ),
);
$pause=array (
  'status' => '1',
  'pic' => '',
  'width' => '',
  'height' => '',
  'link' => '',
);
