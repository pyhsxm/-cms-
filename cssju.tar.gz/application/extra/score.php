<?php
    return ['agents_score'=>20000];