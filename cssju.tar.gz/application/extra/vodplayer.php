<?php
return array (
  'dbm3u8' => 
  array (
    'status' => '1',
    'from' => 'dbm3u8',
    'show' => '百度云M3U8',
    'des' => '在线播放',
    'target' => '_self',
    'ps' => '1',
    'parse' => 'https://kkmdy.top/addons/dplayer/?url=',
    'sort' => '990',
    'tip' => '',
    'id' => 'dbm3u8',
  ),
  'tkm3u8' => 
  array (
    'status' => '1',
    'from' => 'tkm3u8',
    'show' => '天空M3U8',
    'des' => '',
    'target' => '_self',
    'ps' => '1',
    'parse' => 'https://kkmdy.top/addons/dplayer/?url=',
    'sort' => '990',
    'tip' => '',
    'id' => 'tkm3u8',
  ),
  'bjm3u8' => 
  array (
    'status' => '1',
    'from' => 'bjm3u8',
    'show' => 'bjm3u8',
    'des' => '',
    'target' => '_self',
    'ps' => '1',
    'parse' => 'https://kkmdy.top/addons/dplayer/?url=',
    'sort' => '99',
    'tip' => 'bjm3u8',
    'id' => 'bjm3u8',
  ),
);