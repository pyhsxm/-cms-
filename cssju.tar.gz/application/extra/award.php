<?php

return [
    'sign' => [
        'status' => 1,
        'reward' => [
            'points' => 0
        ]
    ]
];