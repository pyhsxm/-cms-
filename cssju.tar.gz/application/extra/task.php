<?php
return array (
  'sign' => 
  array (
    'status' => '0',
    'reward' => 
    array (
      'points' => '10',
    ),
    'title' => '签到',
    'info' => '点击签到即可获得积分',
  ),
  'article' => 
  array (
    'title' => NULL,
    'status' => NULL,
  ),
  'comment' => 
  array (
    'status' => '1',
    'reward' => 
    array (
      'points' => '10',
    ),
    'reward_num' => '1',
    'title' => '评论',
    'info' => '为视频即可获得积分',
  ),
  'dianzan' => 
  array (
    'status' => NULL,
    'reward' => 
    array (
      'points' => NULL,
    ),
    'title' => '点赞',
    'info' => '为视频点赞即可获得积分',
  ),
  'danmu' => 
  array (
    'status' => '1',
    'reward' => 
    array (
      'points' => '10',
    ),
    'reward_num' => '1',
    'title' => '弹幕',
    'info' => '发送弹幕即可获得积分',
  ),
  'mark' => 
  array (
    'status' => '1',
    'reward' => 
    array (
      'points' => '10',
    ),
    'reward_num' => '1',
    'title' => '评分',
    'info' => '为视频评分即可获得积分',
  ),
  'share' => 
  array (
    'status' => '1',
    'reward' => 
    array (
      'points' => '10',
    ),
    'reward_num' => '1',
    'title' => '分享',
    'info' => '分享好友即可获得积分',
  ),
  'view30m' => 
  array (
    'status' => '1',
    'reward' => 
    array (
      'points' => '10',
    ),
    'reward_num' => '1',
    'title' => '观影30分钟',
    'info' => '观影30分钟即可获得积分',
  ),
);