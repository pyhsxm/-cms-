<?php
return array (
  'theme' => 
  array (
    'logo' => 
    array (
      'bpic' => 'upload/site/20210224-1/836b5db267d161ffd4b0bdcf8472c35a.png',
      'wpic' => 'upload/site/20210322-1/8d6ff68ab7d1b70a9032c448cffde2f2.png',
      'icon' => 'upload/site/20210224-1/db4acf0e3989749f875a33df898b11a6.png',
      'webapp' => 'upload/site/20210224-1/f0df5cc462ff6c7c3b5cb0da8445fb9c.png',
    ),
    'lazy' => 'template/conch/asset/img/load.gif',
    'tj' => 
    array (
      'btn' => '1',
    ),
    'head' => 
    array (
      'text' => '',
    ),
    'foot' => 
    array (
      'text' => '<p>本站只提供WEB页面服务，本站不存储、不制作任何视频，不承担任何由于内容的合法性及健康性所引起的争议和法律责任。</p>
<p>若本站收录内容侵犯了您的权益，请附说明联系邮箱，本站将第一时间处理。</p>',
    ),
    'type' => 
    array (
      'hom' => '1,2,3,4',
      'meunbtn' => '1',
      'meunid' => '1,2,3,4,5',
      'meunys' => 'two',
      'ht' => '',
      'ho' => '1,2,3,4',
      'hb' => '999',
      'zb' => '999',
      'mx' => '999',
    ),
    'vod' => 
    array (
      'hnum' => '12',
      'num' => '12',
    ),
    'notice' => 
    array (
      'btn' => '1',
      'text' => '欢迎来到看看猫影视网，温馨提示：<span class=\'mycol\'>请勿相信本站任何广告，如有经济损失，本站概不负责！</span>',
    ),
    'hotvod' => 
    array (
      'btn' => '1',
      'hb' => '1',
      'tj' => '0',
      'title' => '今日更新',
      'num' => 'one',
    ),
    'art' => 
    array (
      'hbtn' => '0',
      'htitle' => '热点资讯',
      'hnum' => '6',
    ),
    'topic' => 
    array (
      'hbtn' => '1',
      'hnum' => '6',
      'title' => '专题',
      'btn' => '0',
    ),
    'actor' => 
    array (
      'hbtn' => '0',
      'htitle' => '荧幕热星',
      'title' => '明星',
      'btn' => '0',
    ),
    'rank' => 
    array (
      'hbtn' => '1',
      'hby' => 'week',
      'hid' => '1,2,3,4',
      'vby' => 'week',
      'btn' => '1',
      'title' => '排行榜',
      'num' => '6',
      'id' => '1,2,3,4',
    ),
    'links' => 
    array (
      'btn' => '1',
      'title' => '友情链接',
      'num' => '30',
    ),
    'banner' => 
    array (
      'btn' => '1',
      'ms' => 'big',
      'smbg' => '1',
      'bgstyle' => '',
    ),
    'lbbanner' => 
    array (
      'btn' => '0',
    ),
    'search' => 
    array (
      'text' => '海量影片精彩看不停',
      'lxbtn' => '1',
    ),
    'play' => 
    array (
      'height' => '56.25',
      'adbtn' => '1',
      'nbtn' => '1',
      'notice' => '<li><span class=\'mytip\'>提醒</span>不要轻易相信视频中的广告，谨防上当受骗!</li>
<li>如果无法播放请重新刷新页面，或者切换线路。</li>
<li>视频载入速度跟网速有关，请耐心等待几秒钟。</li>',
    ),
    'show' => 
    array (
      'filter' => 'a|b|c|d|e',
    ),
    'playlink' => 
    array (
      'btn' => '1',
    ),
    'nav' => 
    array (
      'id' => '1,2,3,4',
      'zdybtn' => '0',
      'zdybtn1' => '0',
      'zdyname1' => '音乐MV',
      'zdylink1' => '/',
      'zdypic1' => 'template/conch/asset/img/ios_fav.png',
      'zdybtn2' => '0',
      'zdyname2' => '',
      'zdylink2' => '',
      'zdypic2' => '',
      'zdybtn3' => '0',
      'zdyname3' => '',
      'zdylink3' => '',
      'zdypic3' => '',
      'zdybtn4' => '0',
      'zdyname4' => '',
      'zdylink4' => '',
      'zdypic4' => '',
    ),
    'rtnav' => 
    array (
      'ym' => 'a|c|f|i',
      'zdybtn1' => '0',
      'zdyname1' => '',
      'zdylink1' => '',
      'zdybtn2' => '0',
      'zdyname2' => '',
      'zdylink2' => '',
    ),
    'fnav' => 
    array (
      'btn' => '1',
      'id' => '1,2,3,4',
      'ym' => 'h|h|g',
      'zdybtn1' => '0',
      'zdyname1' => '自定义1',
      'zdylink1' => '',
      'zdybtn2' => '0',
      'zdyname2' => '自定义2',
      'zdylink2' => '',
    ),
    'share' => 
    array (
      'bdbtn' => '1',
      'zdyfx' => '0',
      'link' => '',
    ),
    'qq' => 
    array (
      'btn' => '0',
      'title' => '联系QQ',
      'link' => 'http://wpa.qq.com/msgrd?v=3&uin=1271001133&site=qq&menu=yes',
    ),
    'weixin' => 
    array (
      'btn' => '0',
      'btntext1' => '微信观看',
      'btntext' => '关注我们，精彩福利看不停',
      'qrcode' => 'upload/site/20201228-1/fdb7fe5b6dd78609365a09a410c6e034.jpg',
      'title' => '关注微信观看',
      'text' => '<p>长按识别二维码或微信扫码关注</p><p>关注后回复片名即可</p><p>或微信搜索微信名：<span class=\'mycol\'>闪讯智联</span></p>

',
    ),
    'zans' => 
    array (
      'btn' => '1',
      'jjtc' => '就知道你会点，哼~！不过还要祝你观影愉快~!',
      'qrcode' => 'upload/site/20210325-1/72fcc68fa1ce7831d207f15621e9342e.png',
      'title' => '感谢赞赏',
      'text' => '<p>长按识别二维码或微信扫描二维码</p><p>金额随意，多少都是支持</p>',
    ),
    'apps' => 
    array (
      'btn' => '1',
      'link' => '/reg/reg.html',
    ),
    'map' => 
    array (
      'btn' => '1',
      'title' => '最近更新',
      'id' => '',
    ),
    'color' => 
    array (
      'select' => 'red',
      'sbtn' => '1',
      'ms' => 'white',
      'mbtn' => '1',
    ),
    'role' => 
    array (
      'title' => '角色',
      'btn' => '0',
    ),
    'plot' => 
    array (
      'title' => '剧情',
      'btn' => '0',
    ),
    'gbook' => 
    array (
      'title' => '留言',
    ),
    'user' => 
    array (
      'title' => '会员',
    ),
    'font' => '0',
    'seos' => 
    array (
      'index_name' => '看看猫影视',
      'index_key' => '看看猫影视',
      'index_des' => '看看猫影视，手机在线电影网每天搜集最新的电影和电视剧，免费电影在线观看视频',
      'detail_name' => '',
      'detail_key' => '',
      'detail_des' => '',
      'play_name' => '',
      'play_key' => '',
      'play_des' => '',
      'down_name' => '',
      'down_key' => '',
      'down_des' => '',
      'arti_name' => '',
      'arti_key' => '',
      'arti_des' => '',
      'artd_name' => '',
      'artd_key' => '',
      'artd_des' => '',
      'topic_name' => '',
      'topic_key' => '',
      'topic_des' => '',
      'topicd_name' => '',
      'topicd_key' => '',
      'topicd_des' => '',
    ),
    'ads' => 
    array (
      'btn' => '1',
      'bottom' => 
      array (
        'btn' => '0',
        'content' => '<a href="#"><img src="https://www.miknio.com" /></a>',
      ),
      'all' => 
      array (
        'btn' => '0',
        'content' => '<a href="#"><img src="https://www.miknio.com" /></a>',
      ),
      'banner' => 
      array (
        'btn' => '0',
        'tbtn' => '0',
        'title' => '24分享网',
        'sub' => '24分享网',
        'link' => 'http://i24n.com',
        'pic' => 'http://i24n.com/tuku/logo.png',
      ),
      'vod_w' => 
      array (
        'btn' => '0',
        'content' => '<a href="#"><img src="https://www.miknio.com" /></a>',
      ),
      'vod_r' => 
      array (
        'btn' => '0',
        'content' => '<a href="#"><img src="https://www.miknio.com/wp-content/themes/b2/Assets/fontend/images/ads-example.jpg" /></a>',
      ),
      'play' => 
      array (
        'btn' => '0',
        'tbtn' => '0',
        'title' => '测试广告',
        'link' => 'http://i24n.com',
        'pic' => 'http://i24n.com/tuku/logo.png',
      ),
      'search_v' => 
      array (
        'btn' => '1',
        'tbtn' => '0',
        'title' => '测试广告',
        'sub' => '测试广告',
        'link' => 'http://i24n.com/',
        'pic' => 'http://i24n.com/tuku/logo.png',
      ),
      'art_w' => 
      array (
        'btn' => '0',
        'content' => '<a href="#"><img src="https://www.miknio.com/wp-content/themes/b2/Assets/fontend/images/ads-example.jpg" /></a>',
      ),
      'art_r' => 
      array (
        'btn' => '0',
        'content' => '<a href="#"><img src="https://www.miknio.com/wp-content/themes/b2/Assets/fontend/images/ads-example.jpg" /></a>',
      ),
      'artlist' => 
      array (
        'btn' => '1',
        'tbtn' => '0',
        'title' => '测试广告',
        'link' => 'http://i24n.com/',
        'pic' => 'http://i24n.com/tuku/logo.png',
      ),
      'user' => 
      array (
        'btn' => '1',
        'pic' => 'http://i24n.com/tuku/logo.png',
      ),
      'tanchuang' => 
      array (
        'kg' => '0',
        'js' => '0.12',
        'bt' => '本站APP已经开放',
        'bz' => 'APP广告',
        'http' => 'http://i24n.com/',
        'qrcode' => 'upload/site/20210105-1/5522ed8d3c8985ea4722e3feecf33b25.png',
        'bt2' => '',
        'bz2' => '',
        'http2' => '',
        'qrcode2' => '',
        'bt3' => '',
        'bz3' => '',
        'http3' => '',
        'qrcode3' => '',
      ),
      'sgg31' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg32' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg2' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg3' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg4' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg5' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg6' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg7' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg8' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg9' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg10' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg11' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg12' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg13' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg14' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg15' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg16' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg17' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg18' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg19' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg20' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg21' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg22' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg23' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg24' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg25' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg26' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg27' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg28' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg29' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
      'sgg30' => 
      array (
        'js' => '',
        'bt' => '',
        'bz' => '',
        'http' => '',
        'qrcode' => '',
      ),
    ),
    'ggclj' => 
    array (
      'kg' => '0',
      'text1' => '',
      'htp1' => '',
      'text2' => '',
      'htp2' => '',
      'text3' => '',
      'htp3' => '',
      'text4' => '',
      'htp4' => '',
      'text5' => '',
      'htp5' => '',
    ),
    'ggzx' => 
    array (
      'jjtc' => '',
      'qrcode' => '',
      'title' => '',
      'text' => '',
    ),
    'tuiguang' => 
    array (
      'bt' => '',
      'text' => '',
    ),
  ),
);