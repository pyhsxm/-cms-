<?php
return array (
  'popupwindo' => 
  array (
    0 => 
    array (
      'status' => '1',
      'title' => '',
      'content' => '',
    ),
    1 => 
    array (
      'status' => '0',
      'title' => '',
      'content' => '',
    ),
    2 => 
    array (
      'status' => '0',
      'title' => NULL,
      'content' => '签到，评论，分享，评分可获得积分',
    ),
    3 => 
    array (
      'status' => '1',
      'title' => NULL,
      'content' => '优先使用WiFi网络播放！如长时间无法播放请点击换来源，如遇卡顿请点击修复，如没有来源可换，请联系客服进行添加播放来源！',
    ),
    4 => 
    array (
      'status' => '0',
      'title' => NULL,
      'content' => '',
    ),
    5 => 
    array (
      'status' => '0',
      'title' => NULL,
      'content' => '',
    ),
  ),
);