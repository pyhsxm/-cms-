<?php
return array (
  'server1' =>
  array (
    'status' => '1',
    'from' => 'server1',
    'show' => '测试服务器1',
    'des' => 'des提示信息1',
    'sort' => '1',
    'tip' => 'tip提示信息1',
    'id' => 'server1',
  ),
);
?>