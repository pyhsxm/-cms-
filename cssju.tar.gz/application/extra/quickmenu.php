<?php
return array (
  0 => '﻿Dp播放器设置,/addons/dplayer/system.php',
  1 => '视频管理,vod/data',
  2 => '海螺模板设置,/admin.php/admin/conch/theme',
  3 => '行分隔符,###',
  4 => '蜘蛛统计,bianxianwangzhizhu/index',
);