<?php
namespace app\common\validate;
use think\Validate;

class Role extends Validate
{
    protected $rule =   [];

    protected $message  =   [];

    protected $scene = [];

}